############################################################################
# Copyright (c) 2023, xeus-cpp contributors                                #
#                                                                          #
# Distributed under the terms of the BSD 3-Clause License.                 #
#                                                                          # 
# The full license is in the file LICENSE, distributed with this software. #
############################################################################

# xeus-cpp cmake module
# This module sets the following variables in your project::
#
#   xeus-cpp_FOUND - true if xeus-cpp was found on the system
#   xeus-cpp_INCLUDE_DIRS - the directory containing xeus-cpp headers
#   xeus-cpp_LIBRARY - the library for dynamic linking
#   xeus-cpp_STATIC_LIBRARY - the library for static linking


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was xeus-cppConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR};${CMAKE_MODULE_PATH}")



include(CMakeFindDependencyMacro)
if (NOT EMSCRIPTEN)
    find_dependency(xeus-zmq )
endif ()

if (NOT TARGET xeus-cpp AND NOT TARGET xeus-cpp-static)
    include("${CMAKE_CURRENT_LIST_DIR}/xeus-cppTargets.cmake")

    if (TARGET xeus-cpp AND TARGET xeus-cpp-static)
        get_target_property(xeus-cpp_INCLUDE_DIR xeus-cpp INTERFACE_INCLUDE_DIRECTORIES)
        get_target_property(xeus-cpp_LIBRARY xeus-cpp LOCATION)
        get_target_property(xeus-cpp_STATIC_LIBRARY xeus-cpp-static LOCATION)
    elseif (TARGET xeus-cpp)
        get_target_property(xeus-cpp_INCLUDE_DIR xeus-cpp INTERFACE_INCLUDE_DIRECTORIES)
        get_target_property(xeus-cpp_LIBRARY xeus-cpp LOCATION)
    elseif (TARGET xeus-cpp-static)
        get_target_property(xeus-cpp_INCLUDE_DIR xeus-cpp-static INTERFACE_INCLUDE_DIRECTORIES)
        get_target_property(xeus-cpp_STATIC_LIBRARY xeus-cpp-static LOCATION)
        set(xeus-cpp_LIBRARY ${xeus-cpp_STATIC_LIBRARY})
    endif ()
endif ()
